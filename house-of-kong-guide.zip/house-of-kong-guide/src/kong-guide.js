/**
 * HOUSE OF KONG GUIDE
 * Culture · Movement · Dominance
 *
 * Lightweight navigation widget for the House of Kong platform.
 * Drop this script + CSS on any page. Zero dependencies.
 */

(function () {
  "use strict";

  // -------------------------------------------------------
  // Configuration — edit these to match your live URLs
  // -------------------------------------------------------
  const CONFIG = {
    links: [
      {
        label: "Project D Lab",
        tag: "The Forge",
        href: "https://projectdlab.blogspot.com/",
        icon: "🔥"
      },
      {
        label: "Danceknightprime",
        tag: "Culture",
        href: "https://danceknightprime.blogspot.com/",
        icon: "⚔️"
      },
      {
        label: "Emdexter",
        tag: "Systems",
        href: "https://emdexter.blogspot.com/",
        icon: "⚙️"
      },
      {
        label: "Main House",
        tag: "Hub",
        href: "https://thehouseofkong.netlify.app/",
        icon: "🏰"
      },
      {
        label: "Podcast",
        tag: "Audio",
        href: "https://open.spotify.com/show/1Uh26YeHc8sQQQd2WjnkIo",
        icon: "🎧"
      }
    ],
    // Optional: rank progression page or protocols
    ranksHref: "https://thehouseofkong.netlify.app/"
  };

  // -------------------------------------------------------
  // SVG: Regal Gorilla (crowned, armored silhouette)
  // -------------------------------------------------------
  const GORILLA_SVG = `
    <svg class="kong-svg" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <!-- Crown -->
      <path class="kong-crown" d="M18 14 L22 8 L28 12 L32 6 L36 12 L42 8 L46 14 L44 18 H20 L18 14Z" fill="#d4af37" stroke="#c9a227" stroke-width="1"/>
      <circle cx="22" cy="11" r="1.6" fill="#f5e6a3"/>
      <circle cx="32" cy="9" r="1.8" fill="#f5e6a3"/>
      <circle cx="42" cy="11" r="1.6" fill="#f5e6a3"/>

      <!-- Head / Face -->
      <ellipse cx="32" cy="30" rx="16" ry="15" fill="#1c1c1e"/>
      <ellipse cx="32" cy="32" rx="13" ry="12" fill="#2a2a2e"/>

      <!-- Brow ridge -->
      <path d="M20 26 Q32 22 44 26" stroke="#0d0d0f" stroke-width="3" stroke-linecap="round" fill="none"/>

      <!-- Eyes -->
      <circle cx="26" cy="30" r="2.8" fill="#d4af37"/>
      <circle cx="38" cy="30" r="2.8" fill="#d4af37"/>
      <circle cx="26.5" cy="29.5" r="1.1" fill="#0a0a0b"/>
      <circle cx="38.5" cy="29.5" r="1.1" fill="#0a0a0b"/>

      <!-- Nose / Muzzle -->
      <ellipse cx="32" cy="37" rx="6" ry="4.5" fill="#1a1a1c"/>
      <ellipse cx="30" cy="36.5" rx="1.4" ry="1" fill="#0d0d0f"/>
      <ellipse cx="34" cy="36.5" rx="1.4" ry="1" fill="#0d0d0f"/>

      <!-- Shoulders / Armor hint -->
      <path d="M14 44 Q32 38 50 44 L48 52 Q32 48 16 52 Z" fill="#1c1c1e"/>
      <path d="M18 46 Q32 42 46 46" stroke="#d4af37" stroke-width="1.5" fill="none" opacity="0.7"/>
    </svg>
  `;

  // Smaller version for panel header
  const MINI_SVG = `
    <svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <path d="M18 14 L22 8 L28 12 L32 6 L36 12 L42 8 L46 14 L44 18 H20 L18 14Z" fill="#d4af37"/>
      <ellipse cx="32" cy="30" rx="16" ry="15" fill="#1c1c1e"/>
      <ellipse cx="32" cy="32" rx="13" ry="12" fill="#2a2a2e"/>
      <circle cx="26" cy="30" r="2.8" fill="#d4af37"/>
      <circle cx="38" cy="30" r="2.8" fill="#d4af37"/>
      <ellipse cx="32" cy="37" rx="6" ry="4.5" fill="#1a1a1c"/>
    </svg>
  `;

  // -------------------------------------------------------
  // Build DOM
  // -------------------------------------------------------
  function createWidget() {
    const root = document.createElement("div");
    root.id = "kong-guide-root";
    root.setAttribute("role", "complementary");
    root.setAttribute("aria-label", "House of Kong navigation guide");

    // Avatar button
    const btn = document.createElement("button");
    btn.className = "kong-avatar-btn";
    btn.setAttribute("aria-expanded", "false");
    btn.setAttribute("aria-controls", "kong-guide-panel");
    btn.setAttribute("title", "Open House of Kong Guide");
    btn.innerHTML = GORILLA_SVG;

    // Panel
    const panel = document.createElement("div");
    panel.id = "kong-guide-panel";
    panel.className = "kong-panel";
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-label", "House navigation");

    // Header
    const header = document.createElement("div");
    header.className = "kong-panel-header";
    header.innerHTML = `
      <div class="mini-avatar">${MINI_SVG}</div>
      <div>
        <div class="kong-panel-title">HOUSE OF KONG</div>
        <div class="kong-panel-sub">Culture · Movement · Dominance</div>
      </div>
    `;

    // Nav
    const nav = document.createElement("ul");
    nav.className = "kong-nav";
    nav.setAttribute("role", "menu");

    CONFIG.links.forEach((item) => {
      const li = document.createElement("li");
      li.className = "kong-nav-item";
      li.setAttribute("role", "none");

      const a = document.createElement("a");
      a.className = "kong-nav-link";
      a.href = item.href;
      a.target = "_blank";
      a.rel = "noopener noreferrer";
      a.setAttribute("role", "menuitem");
      a.innerHTML = `
        <span class="kong-nav-icon">${item.icon}</span>
        <span class="kong-nav-label">${item.label}</span>
        <span class="kong-nav-tag">${item.tag}</span>
      `;

      li.appendChild(a);
      nav.appendChild(li);
    });

    // Footer
    const footer = document.createElement("div");
    footer.className = "kong-panel-footer";
    footer.innerHTML = `Enter only if you intend to <strong>rise</strong>.`;

    panel.appendChild(header);
    panel.appendChild(nav);
    panel.appendChild(footer);

    root.appendChild(panel);
    root.appendChild(btn);

    return { root, btn, panel };
  }

  // -------------------------------------------------------
  // Behaviour
  // -------------------------------------------------------
  function init() {
    // Avoid double-injection
    if (document.getElementById("kong-guide-root")) return;

    const { root, btn, panel } = createWidget();
    document.body.appendChild(root);

    let isOpen = false;

    function open() {
      isOpen = true;
      panel.classList.add("is-visible");
      btn.classList.add("is-open");
      btn.setAttribute("aria-expanded", "true");
    }

    function close() {
      isOpen = false;
      panel.classList.remove("is-visible");
      btn.classList.remove("is-open");
      btn.setAttribute("aria-expanded", "false");
    }

    function toggle() {
      isOpen ? close() : open();
    }

    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      toggle();
    });

    // Close on outside click
    document.addEventListener("click", (e) => {
      if (isOpen && !root.contains(e.target)) {
        close();
      }
    });

    // Close on Escape
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && isOpen) {
        close();
        btn.focus();
      }
    });

    // Optional: first-visit subtle attention
    try {
      const seen = localStorage.getItem("kong-guide-seen");
      if (!seen) {
        setTimeout(() => {
          btn.style.transform = "scale(1.12)";
          setTimeout(() => {
            btn.style.transform = "";
          }, 400);
        }, 1800);
        localStorage.setItem("kong-guide-seen", "1");
      }
    } catch (_) {
      // localStorage may be blocked
    }
  }

  // Boot when DOM is ready
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  // Expose a tiny API for advanced use
  window.KongGuide = {
    open: () => {
      const btn = document.querySelector(".kong-avatar-btn");
      if (btn && !btn.classList.contains("is-open")) btn.click();
    },
    close: () => {
      const btn = document.querySelector(".kong-avatar-btn");
      if (btn && btn.classList.contains("is-open")) btn.click();
    },
    version: "1.0.0"
  };
})();
