# House of Kong Guide

**Culture · Movement · Dominance**

A lightweight, self-contained navigation widget for the House of Kong platform.  
A crowned gorilla sits in the corner of the page and opens a clean navigation panel to the three wings + key destinations.

---

## Features

- Zero dependencies
- Pure vanilla JS + CSS
- Fixed corner avatar with subtle idle animation
- Smooth open/close panel
- Keyboard accessible (Escape to close)
- Mobile-friendly
- Easy to customize links and styling
- Ready for later upgrade to a real 3D model

---

## Quick Start (Local Demo)

1. Clone or download this repo
2. Open `demo/index.html` in any modern browser
3. Click the gorilla in the bottom-right corner

---

## How to put this on GitHub

### 1. Create a new repository

Go to [github.com/new](https://github.com/new) and create a public repo named:

```
house-of-kong-guide
```

### 2. Push the files

In a terminal (or GitHub Desktop):

```bash
cd house-of-kong-guide
git init
git add .
git commit -m "Initial release — House of Kong Guide v1.0"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/house-of-kong-guide.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your actual GitHub username.

---

## How to embed on your sites

### Option A — jsDelivr CDN (easiest after pushing to GitHub)

Add these two lines just before the closing `</body>` tag on any page:

```html
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/YOUR-USERNAME/house-of-kong-guide@main/src/kong-guide.css">
<script src="https://cdn.jsdelivr.net/gh/YOUR-USERNAME/house-of-kong-guide@main/src/kong-guide.js"></script>
```

### Option B — Self-host the files

Upload `src/kong-guide.css` and `src/kong-guide.js` to your own server / Netlify / Blogger theme and reference them with relative or absolute paths.

### Option C — Blogger

1. Go to Theme → Edit HTML
2. Find the `</body>` tag
3. Paste the two CDN lines above it
4. Save

---

## Customizing the links

Open `src/kong-guide.js` and edit the `CONFIG.links` array:

```js
const CONFIG = {
  links: [
    {
      label: "Project D Lab",
      tag: "The Forge",
      href: "https://projectdlab.blogspot.com/",
      icon: "🔥"
    },
    // ... add or remove entries
  ]
};
```

---

## Optional JavaScript API

After the widget loads you can control it from your own code:

```js
KongGuide.open();   // open the panel
KongGuide.close();  // close the panel
console.log(KongGuide.version);
```

---

## Future upgrade path — Real 3D Gorilla

The current version uses a clean SVG silhouette designed to match the House of Kong aesthetic (crown + gold eyes + armor hint).

When you are ready for true 3D:

1. Create or commission a low-poly GLB of the crowned gorilla (Spline, Blender, or AI tools)
2. Host the `.glb` file
3. Replace the avatar button content with Google’s `<model-viewer>` or a small Three.js scene
4. Keep the same panel and navigation logic

The architecture is deliberately simple so this upgrade is straightforward.

---

## File Structure

```
house-of-kong-guide/
├── src/
│   ├── kong-guide.css      # All styles
│   └── kong-guide.js       # Widget logic + SVG
├── demo/
│   └── index.html          # Live demo page
├── assets/                 # (future 3D models, images)
└── README.md
```

---

## License

MIT — free to use and modify for the House of Kong and any personal projects.

---

**The door is open.**  
Enter only if you intend to rise.
