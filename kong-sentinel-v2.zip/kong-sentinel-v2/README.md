# Kong Sentinel v2

**House of Kong — Culture · Movement · Dominance**

Epic navigation + presence widget featuring the armored Gorilla King.

---

## Features

- Real 3D animated gorilla (your Meshy model)
- Context-aware: detects which blog/room the visitor is on
- “Where am I?” + one-tap jumps to the other wings
- Start Here · Series · Search · Popular Labels
- “Who’s the king?” line
- Hidden on mobile (< 768px) — only shows on tablet & desktop
- Zero framework dependencies (vanilla JS + model-viewer)
- Dark + gold House of Kong aesthetic

---

## Quick Start

1. Upload the two files to your repo or host:
   - `src/kong-sentinel.css`
   - `src/kong-sentinel.js`

2. Add before `</body>` on any page:

```html
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/YOUR-USERNAME/kong-sentinel-v2@main/src/kong-sentinel.css">
<script src="https://cdn.jsdelivr.net/gh/YOUR-USERNAME/kong-sentinel-v2@main/src/kong-sentinel.js"></script>
```

Or self-host the paths.

---

## 3D Model

The widget loads your animated GLB directly from:

```
https://raw.githubusercontent.com/danceknightxd/KONGSENTINEL/main/Meshy_AI_Armored_Gorilla_King_20261125_animated_mixamo_All_animation%20(1).glb
```

You can change the URL inside `kong-sentinel.js` → `CONFIG.modelUrl`.

---

## Customising

Open `src/kong-sentinel.js` and edit the `CONFIG` object:

- Room URLs & detection
- Start Here links
- Series
- Labels
- About / Podcast links

---

## Behaviour notes

- On screens narrower than 768px the entire widget is hidden (`display: none`).
- Click the gorilla to open/close the panel.
- Escape or click outside also closes it.
- Search sends a Google site-search across the three blogs.

---

## File structure

```
kong-sentinel-v2/
├── src/
│   ├── kong-sentinel.css
│   └── kong-sentinel.js
├── demo/
│   └── index.html
└── README.md
```

---

**The door is open.**  
Enter only if you intend to rise.
