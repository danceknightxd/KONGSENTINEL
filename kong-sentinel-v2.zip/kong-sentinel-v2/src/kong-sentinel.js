/**
 * KONG SENTINEL v2
 * House of Kong — Culture · Movement · Dominance
 *
 * Epic navigation + presence widget.
 * 3D armored gorilla · context-aware · multi-section panel
 */

(function () {
  "use strict";

  // -------------------------------------------------------
  // CONFIG — edit freely
  // -------------------------------------------------------
  const CONFIG = {
    // Your animated GLB (raw GitHub)
    modelUrl: "https://raw.githubusercontent.com/danceknightxd/KONGSENTINEL/main/Meshy_AI_Armored_Gorilla_King_20261125_animated_mixamo_All_animation%20(1).glb",

    // Rooms
    rooms: {
      emdexter: {
        name: "EMDEXTER",
        tagline: "Tech & Business",
        url: "https://emdexter.blogspot.com/",
        match: ["emdexter.blogspot.com"]
      },
      projectdlab: {
        name: "Project D Lab",
        tagline: "Mindset & Fitness",
        url: "https://projectdlab.blogspot.com/",
        match: ["projectdlab.blogspot.com"]
      },
      danceknight: {
        name: "Danceknightprime",
        tagline: "Culture · Dance · Gaming",
        url: "https://danceknightprime.blogspot.com/",
        match: ["danceknightprime.blogspot.com"]
      },
      home: {
        name: "The House",
        tagline: "Main Hub",
        url: "https://thehouseofkong.netlify.app/",
        match: ["thehouseofkong.netlify.app"]
      }
    },

    // Best entry points
    startHere: {
      emdexter: { label: "Patch Notes", url: "https://emdexter.blogspot.com/search/label/Patch%20Notes" },
      projectdlab: { label: "The Crooked Crown", url: "https://projectdlab.blogspot.com/search/label/The%20Crooked%20Crown" },
      danceknight: { label: "Latest Culture", url: "https://danceknightprime.blogspot.com/" }
    },

    // Series / special
    series: [
      { label: "Latest Patch Notes", url: "https://emdexter.blogspot.com/search/label/Patch%20Notes", icon: "📡" },
      { label: "Latest Crooked Crown", url: "https://projectdlab.blogspot.com/search/label/The%20Crooked%20Crown", icon: "👑" },
      { label: "Surprise me", url: "https://thehouseofkong.netlify.app/", icon: "🎲", random: true }
    ],

    // Popular labels
    labels: [
      { name: "AI", url: "https://emdexter.blogspot.com/search/label/AI" },
      { name: "Business", url: "https://emdexter.blogspot.com/search/label/Business" },
      { name: "Fitness", url: "https://projectdlab.blogspot.com/search/label/Fitness" },
      { name: "Mindset", url: "https://projectdlab.blogspot.com/search/label/Mindset" },
      { name: "Gaming", url: "https://danceknightprime.blogspot.com/search/label/Gaming" },
      { name: "Dance", url: "https://danceknightprime.blogspot.com/search/label/Dance" }
    ],

    aboutUrl: "https://thehouseofkong.netlify.app/",
    podcastUrl: "https://open.spotify.com/show/1Uh26YeHc8sQQQd2WjnkIo"
  };

  // -------------------------------------------------------
  // Detect current room
  // -------------------------------------------------------
  function detectRoom() {
    const host = window.location.hostname.toLowerCase();
    for (const [key, room] of Object.entries(CONFIG.rooms)) {
      if (room.match.some(m => host.includes(m))) return key;
    }
    return "home";
  }

  // -------------------------------------------------------
  // Build DOM
  // -------------------------------------------------------
  function createWidget() {
    const currentKey = detectRoom();
    const current = CONFIG.rooms[currentKey];

    const root = document.createElement("div");
    root.id = "kong-sentinel-root";
    root.setAttribute("role", "complementary");
    root.setAttribute("aria-label", "Kong Sentinel — House of Kong guide");

    // ===== Avatar (3D) =====
    const avatar = document.createElement("button");
    avatar.className = "ks-avatar";
    avatar.setAttribute("aria-expanded", "false");
    avatar.setAttribute("aria-controls", "ks-panel");
    avatar.setAttribute("title", "Open Kong Sentinel");
    avatar.innerHTML = `
      <model-viewer
        src="${CONFIG.modelUrl}"
        alt="Kong Sentinel — Armored Gorilla King"
        camera-controls
        auto-rotate
        auto-rotate-delay="0"
        rotation-per-second="12deg"
        interaction-prompt="none"
        shadow-intensity="0.6"
        exposure="1.05"
        camera-orbit="0deg 75deg 105%"
        min-camera-orbit="auto auto 80%"
        max-camera-orbit="auto auto 140%"
        style="width:100%;height:100%;background:transparent;"
      ></model-viewer>
    `;

    // ===== Panel =====
    const panel = document.createElement("div");
    panel.id = "ks-panel";
    panel.className = "ks-panel";
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-label", "House navigation");

    // Header
    const header = document.createElement("div");
    header.className = "ks-header";
    header.innerHTML = `
      <div class="ks-header-icon">👑</div>
      <div>
        <div class="ks-header-title">KONG SENTINEL</div>
        <div class="ks-header-sub">Culture · Movement · Dominance</div>
      </div>
    `;

    // Body
    const body = document.createElement("div");
    body.className = "ks-body";

    // --- Where am I ---
    const otherRooms = Object.entries(CONFIG.rooms)
      .filter(([k]) => k !== currentKey)
      .map(([k, r]) => `<a class="ks-chip" href="${r.url}" target="_blank" rel="noopener">${r.name}</a>`)
      .join("");

    body.innerHTML += `
      <div class="ks-section">
        <div class="ks-section-label">Where am I?</div>
        <div class="ks-location">
          <div class="ks-location-current">You're in <strong style="color:var(--ks-gold)">${current.name}</strong> — ${current.tagline}</div>
          <div class="ks-location-jumps">${otherRooms}</div>
        </div>
      </div>
    `;

    // --- Start Here ---
    const startLinks = Object.entries(CONFIG.startHere)
      .map(([k, item]) => {
        const room = CONFIG.rooms[k];
        return `
          <a class="ks-link" href="${item.url}" target="_blank" rel="noopener">
            <span class="ks-link-icon">🚪</span>
            <span class="ks-link-text">${item.label}</span>
            <span class="ks-link-tag">${room ? room.name : ""}</span>
          </a>`;
      }).join("");

    body.innerHTML += `
      <div class="ks-section">
        <div class="ks-section-label">Start Here</div>
        ${startLinks}
      </div>
      <div class="ks-divider"></div>
    `;

    // --- Series ---
    const seriesLinks = CONFIG.series.map(s => `
      <a class="ks-link" href="${s.url}" target="_blank" rel="noopener">
        <span class="ks-link-icon">${s.icon}</span>
        <span class="ks-link-text">${s.label}</span>
      </a>
    `).join("");

    body.innerHTML += `
      <div class="ks-section">
        <div class="ks-section-label">Series</div>
        ${seriesLinks}
      </div>
      <div class="ks-divider"></div>
    `;

    // --- Find something ---
    body.innerHTML += `
      <div class="ks-section">
        <div class="ks-section-label">Find something</div>
      </div>
      <div class="ks-search-wrap">
        <input class="ks-search" type="search" placeholder="Search the House…" id="ks-search-input" />
      </div>
      <div class="ks-labels">
        ${CONFIG.labels.map(l => `<a class="ks-label" href="${l.url}" target="_blank" rel="noopener">${l.name}</a>`).join("")}
      </div>
      <div class="ks-divider"></div>
    `;

    // --- Quick links ---
    body.innerHTML += `
      <div class="ks-section">
        <div class="ks-section-label">Quick</div>
        <a class="ks-link" href="${CONFIG.rooms.home.url}" target="_blank" rel="noopener">
          <span class="ks-link-icon">🏰</span>
          <span class="ks-link-text">Main House</span>
        </a>
        <a class="ks-link" href="${CONFIG.podcastUrl}" target="_blank" rel="noopener">
          <span class="ks-link-icon">🎧</span>
          <span class="ks-link-text">Podcast</span>
        </a>
      </div>
    `;

    // About
    const about = document.createElement("a");
    about.className = "ks-about";
    about.href = CONFIG.aboutUrl;
    about.target = "_blank";
    about.rel = "noopener";
    about.textContent = "Who’s the king? — DK / Neal Lloyd";

    // Footer
    const footer = document.createElement("div");
    footer.className = "ks-footer";
    footer.innerHTML = `Enter only if you intend to <strong>rise</strong>.`;

    panel.appendChild(header);
    panel.appendChild(body);
    panel.appendChild(about);
    panel.appendChild(footer);

    root.appendChild(panel);
    root.appendChild(avatar);

    return { root, avatar, panel };
  }

  // -------------------------------------------------------
  // Behaviour
  // -------------------------------------------------------
  function init() {
    if (document.getElementById("kong-sentinel-root")) return;

    // Load model-viewer if needed
    if (!customElements.get("model-viewer")) {
      const script = document.createElement("script");
      script.type = "module";
      script.src = "https://unpkg.com/@google/model-viewer/dist/model-viewer.min.js";
      document.head.appendChild(script);
    }

    const { root, avatar, panel } = createWidget();
    document.body.appendChild(root);

    let isOpen = false;

    function open() {
      isOpen = true;
      panel.classList.add("is-visible");
      avatar.classList.add("is-open");
      avatar.setAttribute("aria-expanded", "true");
    }

    function close() {
      isOpen = false;
      panel.classList.remove("is-visible");
      avatar.classList.remove("is-open");
      avatar.setAttribute("aria-expanded", "false");
    }

    avatar.addEventListener("click", (e) => {
      e.stopPropagation();
      isOpen ? close() : open();
    });

    document.addEventListener("click", (e) => {
      if (isOpen && !root.contains(e.target)) close();
    });

    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && isOpen) {
        close();
        avatar.focus();
      }
    });

    // Simple search → Google site search across the three blogs
    const searchInput = root.querySelector("#ks-search-input");
    if (searchInput) {
      searchInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          const q = searchInput.value.trim();
          if (!q) return;
          const sites = "site:emdexter.blogspot.com OR site:projectdlab.blogspot.com OR site:danceknightprime.blogspot.com";
          window.open(`https://www.google.com/search?q=${encodeURIComponent(q + " " + sites)}`, "_blank");
        }
      });
    }

    // First-visit pulse
    try {
      if (!localStorage.getItem("ks-seen")) {
        setTimeout(() => {
          avatar.style.transform = "scale(1.1)";
          setTimeout(() => { avatar.style.transform = ""; }, 450);
        }, 1600);
        localStorage.setItem("ks-seen", "1");
      }
    } catch (_) {}
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  window.KongSentinel = {
    version: "2.0.0",
    open: () => document.querySelector(".ks-avatar")?.click(),
    close: () => {
      const a = document.querySelector(".ks-avatar");
      if (a?.classList.contains("is-open")) a.click();
    }
  };
})();
